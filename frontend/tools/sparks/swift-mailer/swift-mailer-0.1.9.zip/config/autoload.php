<?php

$autoload['libraries'] = array('SwiftMailer');